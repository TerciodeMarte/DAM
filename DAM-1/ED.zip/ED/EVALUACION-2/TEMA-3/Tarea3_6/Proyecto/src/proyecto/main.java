
package proyecto;

public class main {
    static int x=0,y=5;

    public static void main(String[] args) {
        for (int i = 0; i < 10; i++) {
            incrementa();
        }
       
    }
    public static void incrementa(){
        x++;
    }
    public static void decrementa(){
        x--;
    }
    
}

